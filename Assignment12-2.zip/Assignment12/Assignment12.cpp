#include <iostream>
#include <vector>
#include "Graph.h"
#include <sstream>
#include <fstream>
#include <cstdlib>

using namespace std;


int main(int argc, char* argv[])
{
    Graph <string> g;
    bool run = true;

    char* filename = argv[1];
    //char* filename = "zombieCities.txt";
    ifstream data (filename);

    vector<string> cities;
    string word;

    while(getline(data, word, '\n')) {

        string first;
        stringstream ss;
        ss<<word;
        getline(ss,first,',');

        if(first == "cities"){//cities are added into vertex
            while(getline(ss, word, ',')){
                cities.push_back(word);
                g.addVertex(word);
            }
            continue;
        }

        int index=0;

        string fromcity = first; //type?

        while(getline(ss, word, ',')) {
            int weight = stoi(word);
            string tocity = cities[index];

            if(weight != 0 && weight != -1){
                g.addEdge(fromcity, tocity, weight);
            }
            index++;
        }
    }

    while(run){

        string command;

        cout << "======Main Menu======" << endl;
        cout << "1. Print vertices" << endl;
        cout << "2. Find districts" << endl;
        cout << "3. Find shortest path" << endl;
        cout << "4. Quit" << endl;

        getline(cin, command);
        if(command == "1"){
            g.displayEdges();
        }
        if(command == "2"){
            g.assignDistricts();

        }
        if(command == "3"){
            string start;
            cout << "Enter a starting city:" << endl;
            getline(cin, start);
            string end;
            cout << "Enter an ending city:" << endl;
            getline(cin, end);
            g.shortestPath(start, end);

        }
        if(command == "4"){
           cout<<"Goodbye!"<<endl;
           run = false;
        }

        }
}
