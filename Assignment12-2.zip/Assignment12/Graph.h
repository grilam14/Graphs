#ifndef GRAPH_H
#define GRAPH_H
#include<vector>
#include<iostream>
#include <queue>

using namespace std;

template<class T>
struct vertex;

template<class T>
struct adjVertex{
    vertex<T> *v;
    int weight;
};

template<class T>
struct vertex{
    int ID;
    T name;
    int district=-1;
    bool visited;
    int distance;
    std::vector<adjVertex<T>> adj;
    vertex<T>* parent;

};

template<class T>
struct queueVertex{
    int distance;
    std::vector<vertex <T>*> path;
};

template<class T>
class Graph
{
    public:
        int count = 1; // used to give each city a number/ID
        Graph();
        ~Graph();
        void addEdge(T v1, T v2, int weight);
        void addVertex(T name);
        void displayEdges();
        void assignDistricts();
        void BFTraversalLabel(T startingCity, int distID);
        void shortestPath(T startingCity,T endingCity);
        vertex<T> *findVertex(T name);

    protected:
    private:
        std::vector<vertex<T>> vertices;

};

#endif // GRAPH_H

template<class T>
Graph<T>::Graph()
{

}

template<class T>
Graph<T>::~Graph()
{

}

template<class T>
void Graph<T>::addEdge(T v1, T v2, int weight){

    for(int i = 0; i < vertices.size(); i++){
        if(vertices[i].name == v1){
            for(int j = 0; j < vertices.size(); j++){
                if(vertices[j].name == v2 && i != j){
                    adjVertex<T> av;
                    av.v = &vertices[j];
                    av.weight = weight;
                    vertices[i].adj.push_back(av);
                }
            }
        }
    }

}

template<class T>
void Graph<T>::addVertex(T n){
    bool found = false;
    for(int i = 0; i < vertices.size(); i++){
        if(vertices[i].name == n){
            found = true;
            cout<<vertices[i].name<<" found."<<endl;
        }
    }
    if(found == false){
        vertex<T> v;
        v.name = n;
        vertices.push_back(v);

    }
}

template<class T>
void Graph<T>::assignDistricts(){

    for(int i=0;i<vertices.size();i++){

        if(vertices[i].visited==false){
            vertices[i].district=count;
            BFTraversalLabel(vertices[i].name,count);
        }
    }


}

template<class T>
void Graph<T>::BFTraversalLabel(T startingCity, int distID){

    vertex <T> start = *(findVertex(startingCity));
    start.visited =true;
    queue <vertex<T>> q;
    q.push(start);
    while(!q.empty()){
        vertex<T> n = q.front();
        q.pop();
        for(int i=0; i < n.adj.size(); i++){
            if(!n.adj[i].v->visited){
                n.adj[i].v->visited = true;
                n.adj[i].v->district = count;
                vertex<T> o= *(n.adj[i].v);
                q.push(o);

            }
        }
    }
    count++;
}

template<class T>
void shortestPath(T startingCity,T endingCity){

    vertex<T> length = shortestPath(startingCity, endingCity);
}

template<class T>
void Graph<T>::shortestPath(T startingCity,T endingCity){
    for(int j=0;j<vertices.size();j++){
        vertices[j].visited=false;
    }

    vertex <T> start;
    vertex <T> end;
    if(findVertex(startingCity)){
        start = *findVertex(startingCity);
        }
    if(findVertex(endingCity)){
        end = *findVertex(endingCity);
        }
    if(start.name.empty() || end.name.empty()){
         cout << "One or more cities doesn't exist" << endl;
         return;
    }

    if(start.district != end.district){
        cout << "No safe path between cities" << endl;
        return;
    }

    if(start.district == -1){
        cout << "Please identify the districts before checking distances" << endl;
        return;
    }

    start.visited=true;
    start.distance=0;
    queue <vertex<T>> q;
    q.push(start);
    int counter=0;
    string arr [5];
    while(!q.empty()){
        vertex<T> n = q.front();
        arr[counter]=n.name;
        counter++;
        q.pop();
        for(int i=0;i < n.adj.size(); i++){
            if(!n.adj[i].v->visited){
                n.adj[i].v->distance=n.distance+1;
                n.adj[i].v->parent = &n;
                if(n.adj[i].v->name == endingCity){
                    cout<<n.adj[i].v->distance<<",";
                    cout<<startingCity<<",";
                    for(int i=1;i<counter;i++){
                        cout<<arr[i]<<",";
                    }
                    cout<<endingCity<<endl;
                    return;
                }
                else{
                    n.adj[i].v->visited=true;
                    q.push(*(n.adj[i].v));
                }
            }
        }
    }
    return;
}

template<class T>
vertex<T> *Graph<T>::findVertex(T name){
    vertex <T>* v;
    for(int i=0;i<vertices.size();i++){
        if(vertices[i].name == name){
           return &vertices[i];
        }
    }
    return false;
}


template<class T>
void Graph<T>::displayEdges(){
    //loop through all vertices and adjacent vertices
    for(int i = 0; i < vertices.size(); i++){
        cout<<vertices[i].district<<":";
        cout<<vertices[i].name<<"-->";
        for(int j = 0; j < vertices[i].adj.size(); j++){
            cout<<vertices[i].adj[j].v->name;
            if (j != vertices[i].adj.size()-1)
                cout<<"***";
        }
        cout<<endl;
    }


}

