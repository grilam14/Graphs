//What is the STL?
//A collection of template classes, provided in C++, on commonly used data structures and algorithms
/*It's provided for you and needs to be work for all types*/
//data structures, "container classes"


#include <iostream>

//include the library where vector is defined
#include <vector>

using namespace std;

//vertex with one pointer only
struct vertex{
	int key;
	vertex *adjacent;
};

struct vertex2;

struct adjacent{
    vertex2 *v;
};

//contains a vector of type adjacent that are pointers to vertex2
struct vertex2{
    int key;
    std::vector<adjacent> adj;
};

int main(){
	vector<int> v;
	v.push_back(5); //add a 5 to the vector
	cout<<v.size()<<endl;

	//multiple constructors for a vector
	vector<int> v2(10);
	vector<int> v3(10, 5);

	for(int i = 0; i < v2.size(); i++){
		v2[i] = i;
	}

	//vectors can use iterators to traverse
	vector<int>::iterator it;
	for(it = v2.begin(); it != v2.end(); it++){
		//need to treat the iterator like a pointer and dereference to get value
		cout<<*it<<endl;
	}	

	/*the type in a vector can also be user-defined, such as a class or struct.
	Let's do something a little more complicated than ints. 

	Create a struct called vertex that has a key and a pointer to another vertex,
	which we'll call adjacent.

	Create a vector of 10 vertex, called vertices.
	*/

	vector<vertex> vertices(10);
	for(int i = 0; i < vertices.size(); i++){
		vertices[i].key = i; //assign a key value
	}
	//iterator that uses vertex
	vector<vertex>::iterator it2;
	for(it2 = vertices.begin(); it2 != vertices.end(); it2++){
		//need to treat the iterator like a pointer and dereference to get value
		cout<<it2->key<<endl;
	}	


	//how do I make adjacent point to another element in the vector?
	//element already exists, so we don't need dynamic allocation
	/*adjacent is a pointer that is pointing to a vertex type. We can have it point to
	an existing element of vertices using the address of operator.*/
	vertices[0].adjacent = &vertices[1];

	/*We can test that we're pointing to what we expect by de-referencing the pointer
	and getting the key for the vertex we're pointing to.*/
	cout<<vertices[0].adjacent->key<<endl; //mix of array and pointer dereference notation

	vertices[5].adjacent = &vertices[4];
	vertices[4].adjacent = &vertices[5];


	//what if I want to dynamically allocate a node for adjacent to point to?
	vertices[1].adjacent = new vertex;
	vertices[1].adjacent->key = 100;
	cout<<vertices[1].adjacent->key<<endl;

	//point to more than one node?
	//create a vector of pointers within each vertex
	//created a new struct called vertex2 

	vector<vertex2> ve(10);
	//assign some keys
	for(int i = 0; i < ve.size(); i++){
		ve[i].key = i*10;
	}
	/*adj is currently uninitialized in ve. There's nothing in any of the adjacent vectors
	and there's no size on the vector. We could add a constructor for ve that would initialize
	the adj vector if we wanted to change that. For now, use the vector push_back method.*/

	//we need to create an instance of adjacent
	adjacent a;
	a.v = &ve[1];
	ve[0].adj.push_back(a);
	//dereference the pointer
	//should print 10
	cout<<ve[0].adj[0].v->key<<endl;


}